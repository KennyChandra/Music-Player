import sqlite3

conn = sqlite3.connect("data/users_data.db")

c = conn.cursor()
c.execute("DELETE FROM users WHERE rowid=7")
c.execute("SELECT rowid, * FROM users")

print(c.fetchall())
conn.commit()
conn.close()
