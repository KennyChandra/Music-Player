import bcrypt
from settings import Settings
import sqlite3


conn = sqlite3.connect("data/users_data.db")
setting = Settings()
c = conn.cursor()
def add_newuser(data):
	with setting.conn:
		setting.cur.executemany("""
			INSERT INTO users VALUES (?,?,?,?,?)
			""", data)
		setting.conn.commit()
username = "TheRealTom"
password = "12345"
hashed = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())
first = "Tom"
last = "Brady"
picture = "win.png"


newuserdata = [(username, hashed, first, last, picture)]
add_newuser(newuserdata)


