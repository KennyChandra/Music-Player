class User:
	def __init__(self, username, first, last):
		self.username = username
		self.password = None
		self.first = first
		self.last = last
		self.pic = "win.png"