import sqlite3

class Settings:
	conn = sqlite3.connect("data/users_data.db")
	cur = conn.cursor()