import json
with open("data/users_tracks.json", "r+") as file:
	users = json.load(file)
	for user in users["user"]:
		print(user["username"])
		print(user["tracklist"][0][13:])