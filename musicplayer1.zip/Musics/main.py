import bcrypt
import json
from settings import Settings
from kivymd.app import MDApp
from user import User
from kivy.core.audio import SoundLoader
from kivy.uix.screenmanager import ScreenManager, Screen

from kivymd.uix.button import MDFlatButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.floatlayout import MDFloatLayout

from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout

from kivy.config import Config

from kivy.clock import Clock
from kivy.utils import get_color_from_hex
from kivy.lang import Builder


LabelBase.register(name='Roboto',
					fn_regular='assets/font/Roboto-Thin.ttf',
					fn_bold='assets/font/Roboto-Medium.ttf')

WIDTH = 9*40
HEIGHT = 16*40

Config.set('graphics', 'width', f'{WIDTH}')
Config.set('graphics', 'height', f'{HEIGHT}')
Config.write()

Window.clearcolor = get_color_from_hex("#101216")



class MyApp(MDApp):
	dialog = None
	dialog1 = None

	def __init__(self, **kwargs):
		super().__init__(**kwargs)
		self.settings = Settings()
		self.current_user = None
		self.dialog_box = None
		self.signup_number = 0
		self.music = None

		self.title = "Music Player"
		self.screen_manager = ScreenManager()
		self.screen_manager.add_widget(Builder.load_file("pages/splash.kv"))
		self.screen_manager.add_widget(Builder.load_file("pages/login.kv"))
		self.screen_manager.add_widget(Builder.load_file("pages/dashboard.kv"))
		self.screen_manager.add_widget(Builder.load_file("pages/signup.kv"))

	def build(self):
		self.screen_manager.current = "splash"
		return self.screen_manager

	def on_start(self):
		Clock.schedule_once(self.to_login_page, 3)

	def to_login_page(self, *args):
		self.screen_manager.current = "login"

	def find_user_by_username(self, username):
		with self.settings.conn:
			self.settings.cur.execute("""
				SELECT * FROM users WHERE username=:username
				""", 
				{"username" : username})
		return self.settings.cur.fetchone()

	def logging(self):
		username_entry = self.root.screens[1].ids['usernameinput'].text
		password_entry = self.root.screens[1].ids['password'].text

		user = self.find_user_by_username(username_entry)


		if user:
			with self.settings.conn:
				self.settings.cur.execute("""
					SELECT * FROM users WHERE username=:username
					""",
					{"username": user[0]})
			user = self.settings.cur.fetchall()
			for item in user:
				if bcrypt.checkpw(password_entry.encode("utf-8"), item[1]):
					self.current_user = User(item[0],item[2],item[3])
					self.current_user.pic = item[4]
					self.to_dashboard()
		else:
			self.root.screens[1].ids['msg'].text = "Login Failed"
			self.root.screens[1].ids['usernameinput'].text = ""
			self.root.screens[1].ids['password'].text = ""

	def to_dashboard(self):
		with open("data/users_tracks.json", "r+") as file:
			users = json.load(file)
		for user in users["user"]:
			if self.current_user.username == user["username"]:
				tracklist = user["tracklist"]
	
		user = self.current_user
		fullname = self.current_user.first.title()+" "+ self.current_user.last.title()
		pic = "assets/img/"+self.current_user.pic

		self.root.screens[2].ids['track1'].text = tracklist[0][13:]
		self.root.screens[2].ids['track2'].text = tracklist[1][13:]
		self.root.screens[2].ids['label_username'].text = self.current_user.username
		self.root.screens[2].ids['label_fullname'].text = fullname
		self.root.screens[2].ids['profile_pic'].source = pic

		self.root.current = "dashboard"

	def close_dialog(self, *args):
		self.dialog_box.dismiss()
		self.root.screens[2].ids['nav_drawer'].set_state('close')

	def exit(self, *args):
		self.dialog_box.dismiss()
		self.current_user = None
		self.root.current = "login"

	def add_newuser(self, data):
		with self.settings.conn:
			self.settings.cur.executemany("""
				INSERT INTO users VALUES (?,?,?,?,?)
				""", data)
			self.settings.conn.commit()

	def write_json(self, new_data):
		with open("data/users_tracks.json","r+") as file:
			file_data = json.load(file)
			file_data["user"].append(new_data)
			file.seek(0)
			json.dump(file_data, file, indent = 4)

	def sign_out(self, *args):
		if not self.dialog_box:
			self.dialog_box = MDDialog(
				title="Log Out Confirmation",
				text="Are You Sure You Want To Log Out?",
				buttons=[
					MDFlatButton(
						text="No",
						on_release= self.close_dialog
						),
					MDFlatButton(
						text="Yes",
						on_release= self.exit
						)
				]
				)
		self.dialog_box.open()

	def sign_up(self):
		if not self.dialog:
			self.dialog = MDDialog(
				title = "Haven't Sign Up?",
				buttons =[
					MDFlatButton(
						text="CANCEL", text_color="black", on_release = self.close_dialog1
						),
					MDFlatButton(
						text="SIGN UP", text_color="black", on_release = self.signup_dialog
						),
					],
				)

		self.dialog.open()

	def same_username_alert(self):
		if not self.dialog1:
			self.dialog1 = MDDialog(
				title = "Username Already Existed Pick Another One!",
				buttons =[
					MDFlatButton(
						text="OK", text_color="black", on_release = self.close_dialog2
						),
					],
				)

		self.dialog1.open()

	def signup_dialog(self, obj):
		self.dialog.dismiss()
		if self.signup_number == 0:
			self.screen_manager.current = "signup"
		elif self.signup_number == 1:
			self.to_login_page()

	def signup_process(self):

		username = self.root.screens[3].ids['signedusername'].text
		password = self.root.screens[3].ids['signedpassword'].text
		hashed = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())
		first = self.root.screens[3].ids['signedfirst'].text
		last = self.root.screens[3].ids['signedlast'].text
		user = self.find_user_by_username(username)
		picture = "win.png"
		if username == str():
			self.to_login_page()
		elif password == str():
			self.to_login_page()
		elif first == str():
			self.to_login_page()
		elif last == str():
			self.to_login_page()
		elif user:
			self.same_username_alert()
			self.root.screens[3].ids['signedusername'].text = str()
			self.root.screens[3].ids['signedpassword'].text = str()
			self.root.screens[3].ids['signedfirst'].text = str()
			self.root.screens[3].ids['signedlast'].text = str()
			self.screen_manager.current = "signup"
		else:
			newuserdata = [(username, hashed, first, last, picture)]
			newtrackdata = {
			"username": username,
			"tracklist": ["assets/music/proto1.mp3", "assets/music/proto2.mp3"]
			}
			self.write_json(newtrackdata)
			self.signup_number = 1
			self.add_newuser(newuserdata)
			self.to_login_page()

	def close_dialog1(self, obj):
		self.dialog.dismiss()

	def close_dialog2(self, obj):
		self.dialog1.dismiss()

	def load_music(self, track_title, option): 
		with open("data/users_tracks.json", "r+") as file:
			users = json.load(file)
		for user in users["user"]:
			tracklist = user["tracklist"]
			for track in tracklist:
				if track_title == track[13:]:
					self.music = SoundLoader.load(track)
					if option == "play":
						self.play_music()
					else:
						self.stop_music()

	def play_music(self):
		self.music.play()

	def stop_music(self):
		self.music.stop()

	

if __name__ == '__main__':
	app = MyApp()
	app.run()